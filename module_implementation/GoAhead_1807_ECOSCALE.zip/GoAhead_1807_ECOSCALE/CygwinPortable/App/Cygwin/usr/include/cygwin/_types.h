/* cygwin/_types.h

   Copyright 2004 Red Hat, Inc.

This file is part of Cygwin.

This software is a copyrighted work licensed under the terms of the
Cygwin license.  Please consult the file "CYGWIN_LICENSE" for
details. */

#ifndef _CYGWIN__TYPES_H
#define _CYGWIN__TYPES_H

typedef void *_flock_t;

#endif	/* _CYGWIN__TYPES_H */
